Param($CSVFile="import.csv",$FIMServer="localhost")

set-psdebug -strict

# Hash tables for existing FIM objects, attributes and bindings
$hashFIMObjects = @{}
$hashFIMAttributes = @{}
$hashFIMBindingObjects = @{}
$hashFIMBindingAttributes = @{}

$URI = "http://" + $FIMServer + ":5725/ResourceManagementService"

function GetFIMSchema
{
  $fimschema = Export-FIMConfig -uri $URI -schemaConfig

  foreach ($resource in $fimschema)
  {
    switch ($resource.ResourceManagementObject.ObjectType)
    {    
        "ObjectTypeDescription"
        {
            $name = $resource.ResourceManagementObject.ResourceManagementAttributes  | where {$_.AttributeName -eq 'Name'}
            $guid = $resource.ResourceManagementObject.ResourceManagementAttributes | where {$_.AttributeName -eq 'ObjectID'}
            $hashFIMObjects.add($name.Value,$guid.Value)
        }
        "AttributeTypeDescription"
        {
            $name = $resource.ResourceManagementObject.ResourceManagementAttributes  | where {$_.AttributeName -eq 'Name'}
            $guid = $resource.ResourceManagementObject.ResourceManagementAttributes | where {$_.AttributeName -eq 'ObjectID'}
            $hashFIMAttributes.add($name.Value,$guid.Value)
        }
        "BindingDescription"
        {
            $guid = $resource.ResourceManagementObject.ResourceManagementAttributes | where {$_.AttributeName -eq 'ObjectID'}
            $objectguid = $resource.ResourceManagementObject.ResourceManagementAttributes  | where {$_.AttributeName -eq 'BoundObjectType'}
            $attribguid = $resource.ResourceManagementObject.ResourceManagementAttributes | where {$_.AttributeName -eq 'BoundAttributeType'}
            $hashFIMBindingObjects.add($guid.value,$objectguid.Value)
            $hashFIMBindingAttributes.add($guid.value,$attribguid.value)
        }
    }
  }
}


if(@(get-pssnapin | where-object {$_.Name -eq "FIMAutomation"} ).count -eq 0) {add-pssnapin FIMAutomation}

# Get current FIM schema
GetFIMSchema

# Import CSV file
$csv = import-csv $CSVFile

# Start changes.xml file
get-content 'xml-header.txt' | out-file 'changes.xml' -encoding 'Default'

# Add attributes that don't exist in FIM
write host "Adding attributes:"
foreach ($row in $csv) 
{
  $FIMAttribute = $hashFIMAttributes.Get_Item($row.Attribute)
  if ($FIMAttribute -eq $null) 
  {
    write-host "    " $row.Attribute
    
    $FIMAttrName = $row.Attribute
    $FIMAttrGUID = 'urn:uuid:' + [System.Guid]::NewGuid().toString()
    
    if ($row.'MultiValued'.ToLower() -eq 'true') {$FIMAttrMultiValued = 'true'}
    else  {$FIMAttrMultiValued = 'false'}
            
    switch ($row.DataType)
    {
      'Indexed String' {$FIMAttrDataType = "String"}
      'Unindexed String' {$FIMAttrDataType = "Text"}
      'Reference' {$FIMAttrDataType = "Reference"}
      'Binary' {$FIMAttrDataType = "Binary"}
      'Boolean' {$FIMAttrDataType = "Boolean"}
      'Integer' {$FIMAttrDataType = "Integer"}
    }

    $xmltemplate = get-content 'xml-attribute.txt'
    foreach ($line in $xmltemplate) {$ExecutionContext.InvokeCommand.ExpandString($line) | out-file 'changes.xml' -append  -encoding 'Default'}
  }
}
write-host

# Add bindings
write-host "Adding bindings:"
foreach ($row in $csv) 
{
    $FIMAttribGUID = $hashFIMAttributes.Get_Item($row.Attribute)
    $FIMObjectGUID = $hashFIMObjects.Get_Item($row.ResourceType)
    $bindingExists = $false
    foreach ($binding in $hashFIMBindingAttributes.Keys)
    {
      if ($hashFIMBindingAttributes.Get_Item($binding) -eq $FIMAttribGUID -and $hashFIMBindingObjects.Get_Item($binding) -eq $FIMObjectGUID)
      {
        $bindingExists = $true
      }       
    }
    if (($FIMAttribGUID -ne $null) -and ($FIMObjectGUID -ne $null) -and ($bindingExists -eq $false) )
    {
      write-host "    " $row.Attribute " to " $row.ResourceType
      $FIMAttrGUID = $hashFIMAttributes.Get_Item($row.Attribute)
      $FIMBindGUID = 'urn:uuid:' + [System.Guid]::NewGuid().toString()
      $FIMAttrName = $row.Attribute
    
      $xmltemplate = get-content 'xml-binding.txt'
      foreach ($line in $xmltemplate) {$ExecutionContext.InvokeCommand.ExpandString($line) | out-file 'changes.xml' -append  -encoding 'Default'}   
    }
}


get-content 'xml-footer.txt' | out-file 'changes.xml' -append  -encoding 'Default'

write-host `n`n 'Done. Now you should BACK UP your server, and then run CommitChanges.ps1 using the changes.xml file.'
write-host `n`n 'If you had new attributes in your CSV you will have to run the whole process a second time to create the bindings.'